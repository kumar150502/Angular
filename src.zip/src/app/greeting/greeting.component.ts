// src/app/greeting/greeting.component.ts

import { Component, OnInit } from '@angular/core';
import { parseJwt } from '../Shared/jwtutils';

@Component({
  selector: 'app-greeting',
  templateUrl: './greeting.component.html',
  styleUrls: ['./greeting.component.css'],
})
export class GreetingComponent implements OnInit {
  greetingMessage: string = '';
  username: string = '';

  ngOnInit(): void {
    const token = localStorage.getItem('token');
    const tokenData = parseJwt(token);

    if (tokenData) {
      this.username = tokenData.sub.toUpperCase();
      this.greetingMessage = this.getGreeting();
    }
  }

  private getGreeting(): string {
    const hours = new Date().getHours();
    if (hours < 12) {
      return 'Good Morning';
    } else if (hours < 18) {
      return 'Good Afternoon';
    } else {
      return 'Good Evening';
    }
  }
}
