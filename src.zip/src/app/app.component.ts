import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true, // Keep it as a standalone component
  imports: [RouterOutlet], // Import RouterOutlet for routing
  templateUrl: './app.component.html', // Path to the template
  styleUrls: ['./app.component.scss'], // Pluralized `styleUrls`
})
export class AppComponent {
  title = 'angularproject'; // Root component title
}
