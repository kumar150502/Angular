import { Routes } from '@angular/router';
import { AppComponent } from './app.component';

// Example routes, adjust as per your components
export const routes: Routes = [
  { path: '', component: AppComponent }, // Home route
  // Add other routes as necessary
];
